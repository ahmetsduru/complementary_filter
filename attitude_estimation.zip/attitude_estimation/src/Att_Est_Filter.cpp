#include "../include/attitude_estimation/Att_Est_Filter.h"

// Magnetometer callback to update magnetometer data
void Att_Est_Filter::magnetometer_callback(const sensor_msgs::MagneticField::ConstPtr &msg){
    m_latest_mag_msg = msg;
    m_magnetometer = { (msg -> magnetic_field.x/120), 
                       (msg -> magnetic_field.y/120), 
                       (msg -> magnetic_field.z/120)};
}

// Function to estimate attitude from accelerometer and magnetometer data
void Att_Est_Filter::attitude_from_acc_mag(const sensor_msgs::Imu::ConstPtr &msg){

    if (m_latest_mag_msg) {
        Att_Est_Filter::magnetometer_callback(m_latest_mag_msg);
    }
    else{
        ROS_WARN("NO MAG DATA RECEIVED");
    }
    m_acceleration = {msg -> linear_acceleration.x,
                      msg -> linear_acceleration.y,
                      msg -> linear_acceleration.z};
    
    double acc_norm = sqrt(pow(m_acceleration[0], 2) + pow(m_acceleration[1], 2) + pow(m_acceleration[2], 2));

    if (acc_norm == 0) {
        ROS_ERROR("Acceleration norm is zero, cannot normalize.");
        return;
    }

    m_normalized_acceleration[0] = m_acceleration[0] / acc_norm;
    m_normalized_acceleration[1] = m_acceleration[1] / acc_norm;
    m_normalized_acceleration[2] = m_acceleration[2] / acc_norm;

    m_tilt_acc[0] = atan2(m_normalized_acceleration[1],m_normalized_acceleration[2]);
    m_tilt_acc[1] = atan2(-m_normalized_acceleration[0],sqrt(pow(m_normalized_acceleration[1],2)+pow(m_normalized_acceleration[2],2)));
    m_tilt_acc[2] = 0;

    double mag_norm = sqrt(pow(m_magnetometer[0], 2) + pow(m_magnetometer[1], 2) + pow(m_magnetometer[2], 2));
    
    if (mag_norm == 0) {
        ROS_ERROR("Magnetometer norm is zero, cannot normalize.");
        return;
    }
        
    m_n_magnetometer[0] = m_magnetometer[0] / mag_norm; 
    m_n_magnetometer[1] = m_magnetometer[1] / mag_norm;
    m_n_magnetometer[2] = m_magnetometer[2] / mag_norm;

    m_b[0] = m_n_magnetometer[0]*cos(m_tilt_acc[1]) + m_n_magnetometer[1]*sin(m_tilt_acc[0])*sin(m_tilt_acc[1]) + m_n_magnetometer[2]*sin(m_tilt_acc[1])*cos(m_tilt_acc[0]);
    m_b[1] = m_n_magnetometer[1]*cos(m_tilt_acc[0]) - m_n_magnetometer[2]*sin(m_tilt_acc[0]);
    m_b[2] = -m_n_magnetometer[0]*sin(m_tilt_acc[1]) + m_n_magnetometer[1]*cos(m_tilt_acc[1])*sin(m_tilt_acc[0]) + m_n_magnetometer[2]*cos(m_tilt_acc[0])*cos(m_tilt_acc[1]);

    m_tilt_acc[2] = atan2(-m_b[1],m_b[0]);

    m_orientation[0] = m_tilt_acc[0];
    m_orientation[1] = m_tilt_acc[1];
    m_orientation[2] = m_tilt_acc[2];
    ROS_INFO("mb1 %f   mb2 %f   mb3 %f",m_orientation[0],m_orientation[1],m_orientation[2]);

}

// Function to estimate attitude from angular rate
void Att_Est_Filter::att_from_ang_rate(const Vector3d &x, Vector3d &dxdt, const double t){
    dxdt[0] = m_ang_vel[0]+sin(x[0])*tan(x[1])*m_ang_vel[1]+cos(x[0])*tan(x[1])*m_ang_vel[2];
    dxdt[1] = cos(x[0])*m_ang_vel[1]-sin(x[0])*m_ang_vel[2];
    dxdt[2] = ((m_ang_vel[1]*sin(x[0]))/cos(x[1]))+((m_ang_vel[2]*cos(x[0]))/cos(x[1]));
}

// Complementary filter implementation
void Complementary_Filter::complementary_filter(const sensor_msgs::Imu::ConstPtr &msg){

    m_gyroscope = { msg->angular_velocity.x, 
                    msg->angular_velocity.y, 
                    msg->angular_velocity.z};
    m_ang_vel = m_gyroscope;

    Att_Est_Filter::attitude_from_acc_mag(msg); 
    
    if(m_is_first_run){
        m_is_first_run = false;
        m_q_gyro[0] = m_orientation[0];
        m_q_gyro[1] = m_orientation[1];
        m_q_gyro[2] = m_orientation[2];
        ROS_WARN("FIRST RUN");
    }
    typedef runge_kutta_cash_karp54< Vector3d > error_stepper_rkck54;
    double errAbs = 1.0e-10;
    double errRel = 1.0e-6;
    double m_alpha = 0.9;
    double m_imu_period = 0.05; // 20 hz

    auto system = [this](const Vector3d &x, Vector3d &dxdt, const double t) {
        this->att_from_ang_rate(x, dxdt, t);
    };
    
    // Integrate angular rates to update attitude estimate
    integrate_adaptive(make_controlled(errAbs, errRel, error_stepper_rkck54()), system, m_q_gyro, 0.0, m_imu_period, m_imu_period);
    
    // Publish the updated attitude
    m_complementary_pub.x = (1-m_alpha)*m_orientation[0] + m_alpha*m_q_gyro[0];
    m_complementary_pub.y = (1-m_alpha)*m_orientation[1] + m_alpha*m_q_gyro[1];
    m_complementary_pub.z = (1-m_alpha)*m_orientation[2] + m_alpha*m_q_gyro[2];
    m_pub.publish(m_complementary_pub);

    m_q_gyro[0] = m_complementary_pub.x;
    m_q_gyro[1] = m_complementary_pub.y;
    m_q_gyro[2] = m_complementary_pub.z;
}
