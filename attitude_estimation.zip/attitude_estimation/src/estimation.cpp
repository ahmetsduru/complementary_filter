#include "../include/attitude_estimation/Att_Est_Filter.h"

using namespace std;

int main(int argc, char **argv)
{
    
    ros::init(argc,argv, "attitude_estimation");
    ros::NodeHandle nh;
    ros::Rate loop_rate(100);
    Complementary_Filter tilt;
    Att_Est_Filter mag;
    ros::Subscriber imu_sub = nh.subscribe("/mavros/imu/data",100,&Complementary_Filter::complementary_filter,&tilt);
    ros::Subscriber mag_sub = nh.subscribe<sensor_msgs::MagneticField>("/mavros/imu/mag", 100, 
        [&tilt](const sensor_msgs::MagneticField::ConstPtr &msg) { tilt.magnetometer_callback(msg); });
    
    tilt.m_pub = nh.advertise<geometry_msgs::Vector3>("topic_tilt",100);
    ros::spin();

    return 0;
}
