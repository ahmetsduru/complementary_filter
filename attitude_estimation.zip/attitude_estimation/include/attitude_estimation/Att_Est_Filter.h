#ifndef ATT_EST_FILTER_H_
#define ATT_EST_FILTER_H_

#include <ros/ros.h>
#include <sensor_msgs/MagneticField.h>
#include <sensor_msgs/Imu.h>
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
#include <boost/numeric/odeint.hpp>
#include <eigen3/Eigen/Geometry>
#include <geometry_msgs/Vector3.h>

using namespace std;
using namespace Eigen;
using namespace boost::numeric::odeint;

class Att_Est_Filter
{
    public:
    Vector3d m_magnetometer;
    Vector3d m_n_magnetometer;
    Vector3d m_angular_velocity;
    Vector3d m_acceleration;
    Vector3d m_normalized_acceleration;
    Vector3d m_orientation;
    Vector3d m_ang_vel;
    Vector3d m_gyroscope;
    Vector3d m_q_gyro;
    Vector3d m_b;
    Vector3d m_tilt_acc;
    geometry_msgs::Vector3 m_complementary_pub;
    ros::Publisher m_pub;
    sensor_msgs::MagneticField::ConstPtr m_latest_mag_msg;
    
    void att_from_ang_rate(const Vector3d &x, Vector3d &dxdt, const double t);
    void magnetometer_callback(const sensor_msgs::MagneticField::ConstPtr &msg);
    void attitude_from_acc_mag(const sensor_msgs::Imu::ConstPtr &msg);
};

class Complementary_Filter : public Att_Est_Filter
{
    public:
    Vector3d m_q_complementary;
    bool m_is_first_run = true;
    
    
    void complementary_filter(const sensor_msgs::Imu::ConstPtr &msg);
};

#endif